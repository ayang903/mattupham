import csv
from youtube_search import YoutubeSearch
from youtube_transcript_api import YouTubeTranscriptApi
from pytube import YouTube
from itertools import islice

def search_videos(query, max_results):
    search = YoutubeSearch(query, max_results=max_results)
    results = search.to_dict()
    return [result['id'] for result in results]

def get_video_info(video_id):
    yt = YouTube(f"https://www.youtube.com/watch?v={video_id}")
    title = yt.title
    url = yt.watch_url
    try:
        transcript_data = YouTubeTranscriptApi.get_transcript(video_id)
        transcript = " ".join([entry['text'] for entry in transcript_data])
    except:
        transcript = "Transcript not available"
    return title, url, transcript

def scrape_videos(video_ids):
    with open('video_data.csv', mode='w', newline='', encoding='utf-8') as file:
        writer = csv.writer(file)
        writer.writerow(["Title", "URL", "Transcript"])  # Header row
        for video_id in video_ids:
            print(f"Processing video ID {video_id}...")
            video_info = get_video_info(video_id)
            writer.writerow(video_info)

if __name__ == "__main__":
    query = 'tech news'
    max_results = 5
    video_ids = search_videos(query, max_results)
    scrape_videos(video_ids)
